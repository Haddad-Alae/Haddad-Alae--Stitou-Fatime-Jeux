#ifndef _DEFINITIONS_H_
#define _DEFINITIONS_H_ 

#define DISPLAY_TIME_SPLASH_SCENE 3  // la scene Splash_Scene va etre afficher durant 3 second
#define TRANSITION_TIME 1   // la vitesse de transition entre les diferents scenes est de 1 
#define BALL_SPEED 0.1   // la vitesse du mouvement du ball 
#define CC_CALLBACK_2
#define BALL_SPEED 0.1


#define LEFT 104
#define UP
#define DOWN
#define RIGHT 103



#endif // _DEFINITIONS_H_